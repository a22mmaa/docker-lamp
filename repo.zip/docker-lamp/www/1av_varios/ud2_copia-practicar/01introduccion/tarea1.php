<?php
/*
Localiza y corrige los errores de este programa PHP:
```php
<? php
echo '¿Cómo estás';
echo 'Estoy bien, gracias.';
??>
```
**/
