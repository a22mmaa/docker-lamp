<?php

/**
 * Indica cuál de los siguientes son nombres de variables válidas e inválidos, indica por qué (en comentarios) y corrige los fallos:
- valor 
- $_N
- $valor_actual 
- $n
- $#datos 
- $valorInicial0
- $proba,valor 
- $2saldo
- $n
- $meuProblema
- $meu Problema
- $echo
- $m&m
- $registro
- $ABC
- $85 Nome
- $AAAAAAAAA
- $nome_apelidos
- $saldoActual
- $92
- $*143idade
 */
?>