<?php

//Usando la instrucción ```echo``` crea un programa en PHP que muestre el mensaje: ```Hola, Mundo!```  Optativo. Muéstralo en cursiva.

//Crea un programa en PHP que guarde en una variable tu nombre y lo muestre en negrita formando el siguiente mensaje: Bienvenido tunombre

?>