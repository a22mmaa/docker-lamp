<?php

require 'lib/utilidades.php';




if(comprobaTamanho(500000)) {
    echo "check";
} else {
    echo "nop";
}