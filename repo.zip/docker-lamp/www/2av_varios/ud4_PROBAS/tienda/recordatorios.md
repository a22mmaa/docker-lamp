# Recordatorios

1. En index.php mete as cousas novas:
    - Links
    - crear a nova táboa (coa sua función)

2. Importante cambiar as cabeceiras do form, non só o contido

3. Comprobar todo o que está debaixo de "NOVIDAD€S" en base_datos e utilidades

4. Nas version con multiples subidas, marco isto con // DIFER€NZA

5. Dar PERMISOS ás carpetas nas que subirán os arquivos

6. Ao facer o do login e meter o da pass, seguramente haxa que borrar a taboa vella da BD

aceso a BD: *user*: root; *pass*: test