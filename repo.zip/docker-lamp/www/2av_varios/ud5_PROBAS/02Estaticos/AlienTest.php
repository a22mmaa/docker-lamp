<?php

require 'Alien.php';

    $alien1 = new Alien('fulano');
    $alien2 = new Alien('mengano');

    echo Alien::getNumberOfAliens();




                                                                                                                               