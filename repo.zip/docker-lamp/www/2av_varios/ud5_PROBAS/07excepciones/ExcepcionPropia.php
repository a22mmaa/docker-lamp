<?php

class ExcepcionPropia extends Exception {

}