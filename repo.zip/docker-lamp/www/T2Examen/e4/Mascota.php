<?php

interface Mascota
{
    public function obtenernombre();
    public function emitirSonido();
}