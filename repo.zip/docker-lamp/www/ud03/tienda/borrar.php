<?php
//Obter conexión
//Seleccionar a bd
//Ler o id de $_GET
//Executar consulta de borrado (delete)