<?php
/**
 * Interface de CalculosCentroEstudios
 */
interface CalculosCentroEstudios {
    public function numeroDeAprobados();
    public function numeroDeSuspensos();
    public function notaMedia();
}