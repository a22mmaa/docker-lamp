<?php

require_once 'Data.php';
use ud05\Data;

echo Data::getDataHora();
