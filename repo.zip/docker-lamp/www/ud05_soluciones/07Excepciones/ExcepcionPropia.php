<?php

namespace ud05;

use Exception;

class ExcepcionPropia extends Exception
{
    // No es necesario añadir ningún código adicional aquí
}
