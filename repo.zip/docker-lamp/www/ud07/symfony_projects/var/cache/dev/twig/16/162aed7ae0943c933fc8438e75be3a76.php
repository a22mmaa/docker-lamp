<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* libros/sobre.html.twig */
class __TwigTemplate_ab87ac2002d072236f008834ddb3765b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 2
        return "bootstrap/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "libros/sobre.html.twig"));

        $this->parent = $this->loadTemplate("bootstrap/base.html.twig", "libros/sobre.html.twig", 2);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        yield "
";
        // line 8
        yield "<h1>";
        yield Twig\Extension\EscaperExtension::escape($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 8, $this->source); })()), "html", null, true);
        yield "</h1>

    ";
        // line 11
        yield "    <div>
        <h2>Sobre min</h2>
        <p>Ola! Chámome ";
        // line 13
        yield Twig\Extension\EscaperExtension::escape($this->env, (isset($context["nome"]) || array_key_exists("nome", $context) ? $context["nome"] : (function () { throw new RuntimeError('Variable "nome" does not exist.', 13, $this->source); })()), "html", null, true);
        yield ". Gústame ler e creei esta web para organizar a miña biblioteca.</p>
        <p>As miñas afeccións son:
            <ul>
                ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["afeccions"]) || array_key_exists("afeccions", $context) ? $context["afeccions"] : (function () { throw new RuntimeError('Variable "afeccions" does not exist.', 16, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["afeccion"]) {
            // line 17
            yield "                    <li>";
            yield Twig\Extension\EscaperExtension::escape($this->env, $context["afeccion"], "html", null, true);
            yield "</li>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['afeccion'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        yield "            <ul>
        </p>
    </div>
    
    ";
        // line 24
        yield "    <div>
        <h2>Sobre a biblioteca</h2>
        <p>Compro libros constantemente, e esta biblioteca actualmente posúe ";
        // line 26
        yield Twig\Extension\EscaperExtension::escape($this->env, (isset($context["n_exemplares"]) || array_key_exists("n_exemplares", $context) ? $context["n_exemplares"] : (function () { throw new RuntimeError('Variable "n_exemplares" does not exist.', 26, $this->source); })()), "html", null, true);
        yield " exemplares, aínda que seguramente o número siga medrando.</p>
    </div>
    
    <hr/>
    
    ";
        // line 32
        yield "    <footer>
    <p>Ponte en contacto comigo a través do meu correo: <a href=\"mailto:";
        // line 33
        yield Twig\Extension\EscaperExtension::escape($this->env, (isset($context["mail"]) || array_key_exists("mail", $context) ? $context["mail"] : (function () { throw new RuntimeError('Variable "mail" does not exist.', 33, $this->source); })()), "html", null, true);
        yield "\">";
        yield Twig\Extension\EscaperExtension::escape($this->env, (isset($context["mail"]) || array_key_exists("mail", $context) ? $context["mail"] : (function () { throw new RuntimeError('Variable "mail" does not exist.', 33, $this->source); })()), "html", null, true);
        yield "</a>.</p>
    </footer>


";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "libros/sobre.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  113 => 33,  110 => 32,  102 => 26,  98 => 24,  92 => 19,  83 => 17,  79 => 16,  73 => 13,  69 => 11,  63 => 8,  60 => 6,  53 => 5,  36 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{# Chamamos á plantilla base #}
{% extends 'bootstrap/base.html.twig' %}

{# Iniciamos o bloque de contidos #}
{% block body %}

{# Título desta páxina #}
<h1>{{ title }}</h1>

    {# Apartado para falar sobre min. Recibe a variábel co meu nome e o array das afeccións #}
    <div>
        <h2>Sobre min</h2>
        <p>Ola! Chámome {{ nome }}. Gústame ler e creei esta web para organizar a miña biblioteca.</p>
        <p>As miñas afeccións son:
            <ul>
                {% for afeccion in afeccions %}
                    <li>{{ afeccion }}</li>
                {% endfor %}
            <ul>
        </p>
    </div>
    
    {# Apartado para falar sobre a biblioteca. Recibe a variábel co número de exemplares #}
    <div>
        <h2>Sobre a biblioteca</h2>
        <p>Compro libros constantemente, e esta biblioteca actualmente posúe {{ n_exemplares }} exemplares, aínda que seguramente o número siga medrando.</p>
    </div>
    
    <hr/>
    
    {# No futuro footer convídase a poñerse en contacto. Recibe a variábel mail, que usa para crear un mailto: #}
    <footer>
    <p>Ponte en contacto comigo a través do meu correo: <a href=\"mailto:{{ mail }}\">{{ mail }}</a>.</p>
    </footer>


{% endblock %}

", "libros/sobre.html.twig", "/symfony_projects/templates/libros/sobre.html.twig");
    }
}
