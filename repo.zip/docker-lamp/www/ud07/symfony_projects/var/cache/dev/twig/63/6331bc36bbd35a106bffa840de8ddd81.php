<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* libros/abreviaturas.html.twig */
class __TwigTemplate_d25bf90dd522f2b14c108dc1c8903ea6 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "bootstrap/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "libros/abreviaturas.html.twig"));

        $this->parent = $this->loadTemplate("bootstrap/base.html.twig", "libros/abreviaturas.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        yield "
";
        // line 6
        yield "<h1>";
        yield Twig\Extension\EscaperExtension::escape($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 6, $this->source); })()), "html", null, true);
        yield "</h1>

    <div>
        <h2>Xéneros dispoñíbeis</h2>
    
        <ul>
        ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["xeneros"]) || array_key_exists("xeneros", $context) ? $context["xeneros"] : (function () { throw new RuntimeError('Variable "xeneros" does not exist.', 12, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["xenero"]) {
            // line 13
            yield "            <li>
                ";
            // line 14
            yield Twig\Extension\EscaperExtension::escape($this->env, $context["xenero"], "html", null, true);
            yield "
            </li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['xenero'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        yield "        </ul>
    </div>
    
    <div>
        <h2>Tipos de libros</h2>
    
        <dl>
            ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((isset($context["tipos"]) || array_key_exists("tipos", $context) ? $context["tipos"] : (function () { throw new RuntimeError('Variable "tipos" does not exist.', 24, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["tipo"]) {
            // line 25
            yield "                <dt>";
            yield Twig\Extension\EscaperExtension::escape($this->env, Twig\Extension\CoreExtension::upperFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["tipo"], "abreviatura", [], "any", false, false, false, 25)), "html", null, true);
            yield ":</dt>
                <dd>";
            // line 26
            yield Twig\Extension\EscaperExtension::escape($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["tipo"], "expansion", [], "any", false, false, false, 26), "html", null, true);
            yield "</dd>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tipo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        yield "        </dl>
    </div>
  </body>
</html>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "libros/abreviaturas.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  115 => 28,  107 => 26,  102 => 25,  98 => 24,  89 => 17,  80 => 14,  77 => 13,  73 => 12,  63 => 6,  60 => 4,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'bootstrap/base.html.twig' %}

{% block body %}

{# Título desta páxina #}
<h1>{{ title }}</h1>

    <div>
        <h2>Xéneros dispoñíbeis</h2>
    
        <ul>
        {% for xenero in xeneros %}
            <li>
                {{ xenero }}
            </li>
        {% endfor %}
        </ul>
    </div>
    
    <div>
        <h2>Tipos de libros</h2>
    
        <dl>
            {% for tipo in tipos %}
                <dt>{{ tipo.abreviatura | upper }}:</dt>
                <dd>{{ tipo.expansion }}</dd>
            {% endfor %}
        </dl>
    </div>
  </body>
</html>

{% endblock %}

", "libros/abreviaturas.html.twig", "/symfony_projects/templates/libros/abreviaturas.html.twig");
    }
}
