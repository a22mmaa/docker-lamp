<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* libros/xeneros.html.twig */
class __TwigTemplate_22db9bbdd137104794a75e0f8508aa75 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "bootstrap/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "libros/xeneros.html.twig"));

        $this->parent = $this->loadTemplate("bootstrap/base.html.twig", "libros/xeneros.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        yield "
";
        // line 6
        yield "<h1>Explorar ";
        yield Twig\Extension\EscaperExtension::escape($this->env, Twig\Extension\CoreExtension::lowerFilter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 6, $this->source); })())), "html", null, true);
        yield "</h1>

    <div>
      ";
        // line 9
        if (((isset($context["xenero"]) || array_key_exists("xenero", $context) ? $context["xenero"] : (function () { throw new RuntimeError('Variable "xenero" does not exist.', 9, $this->source); })()) == null)) {
            // line 10
            yield "        Sección dedicada a explorar todos os xéneros da biblioteca.
      ";
        }
        // line 12
        yield "      ";
        if (((isset($context["xenero"]) || array_key_exists("xenero", $context) ? $context["xenero"] : (function () { throw new RuntimeError('Variable "xenero" does not exist.', 12, $this->source); })()) != null)) {
            // line 13
            yield "        Sección dedicada ao xénero: ";
            yield Twig\Extension\EscaperExtension::escape($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 13, $this->source); })()), "html", null, true);
            yield "
      ";
        }
        // line 15
        yield "
    </div>
  </body>
</html>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "libros/xeneros.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  85 => 15,  79 => 13,  76 => 12,  72 => 10,  70 => 9,  63 => 6,  60 => 4,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'bootstrap/base.html.twig' %}

{% block body %}

{# Título desta páxina #}
<h1>Explorar {{ title | lower }}</h1>

    <div>
      {% if xenero == null %}
        Sección dedicada a explorar todos os xéneros da biblioteca.
      {% endif %}
      {% if xenero != null %}
        Sección dedicada ao xénero: {{ title }}
      {% endif %}

    </div>
  </body>
</html>

{% endblock %}

", "libros/xeneros.html.twig", "/symfony_projects/templates/libros/xeneros.html.twig");
    }
}
