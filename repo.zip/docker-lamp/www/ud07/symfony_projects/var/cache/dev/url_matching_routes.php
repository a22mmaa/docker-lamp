<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'app_libros_homepage', '_controller' => 'App\\Controller\\LibrosController::homepage'], null, null, null, false, false, null]],
        '/sobre' => [[['_route' => 'app_libros_sobre', '_controller' => 'App\\Controller\\LibrosController::sobre'], null, null, null, false, false, null]],
        '/abreviaturas' => [[['_route' => 'app_libros_abreviaturas', '_controller' => 'App\\Controller\\LibrosController::abreviaturas'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/explorar(?:/([^/]++))?(*:65)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        65 => [
            [['_route' => 'app_libros_explorar', 'xenero' => null, '_controller' => 'App\\Controller\\LibrosController::explorar'], ['xenero'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
