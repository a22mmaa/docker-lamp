<?php
    echo '¿Cómo estás';
    echo 'Estoy bien, gracias.';

    $final = 3;

    echo 'a';

    $AAAAAAAAA = 'aa';

    echo $AAAAAAAAA;

?>