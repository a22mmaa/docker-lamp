<?php

//Usando la instrucción ```echo``` crea un programa en PHP que muestre el mensaje: ```Hola, Mundo!```  Optativo. Muéstralo en cursiva.

    echo '<em>Hola, mundo</em>';
    
//Crea un programa en PHP que guarde en una variable tu nombre y lo muestre en negrita formando el siguiente mensaje: Bienvenido tunombre
    $nome = "Manuel";
    echo "<br/>Bienvenido, <strong>" . $nome . "</strong>.";


?>